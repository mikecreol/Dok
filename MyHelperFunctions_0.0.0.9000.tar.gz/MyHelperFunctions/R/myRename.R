#' Renames variables in a data frame. The interface that looks intuitive to me
#'
#' @param data - the dataframe
#' @param old.names - a character vector with the old names
#' @return new.names - a character vector with the new names
#' @export

myRename <- function(data, old.names, new.names){
  rename.vec <- new.names # temp object used for renaming see the documentation of rename
  names(rename.vec) <- old.names
  return(plyr::rename(data, rename.vec))
}