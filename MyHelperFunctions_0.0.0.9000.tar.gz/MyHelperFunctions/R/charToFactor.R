#' Converts the character vars in a dataframe to factors
#'
#' @param df - dataframe with character variables
#' @return a dataframe in which character variables are converted to factors
#' @export

charToFactor <- function(df){
  char.vars <- sapply(df, is.character)
  df[char.vars] <- lapply(df[char.vars], as.factor)
  return(df)
}

