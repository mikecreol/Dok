#' Recodes values in a data frame with the interface that looks intuitive to me
#'
#' @param Data - the dataframe
#' @param orig - vector with values to be replaced
#' @param replace - vector with values for replacement
#' @return new.names - a matrix with replaced values
#' @export

replaceValues <- function(Data, orig, replace){
  
  if(length(orig) != length(replace)){
    stop("Lengths of orig and replace differ!")
  }
  
  for(i in 1:length(orig)){
    if(is.na(orig[i])){
      Data[is.na(Data)] <- replace[i]
    } else if(is.nan(orig[i])){
      Data[is.nan(Data)] <- replace[i]
    } else {
      Data[Data == orig[i]] <- replace[i]
    } 
  }
  
  return(Data)
}