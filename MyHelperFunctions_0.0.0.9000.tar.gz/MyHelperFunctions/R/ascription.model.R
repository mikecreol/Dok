#' Create a random forest model for ascription
#' 
#' @param Y.var A string or a column index, indicating which variable is the predictor
#' @param data A dataframe for the modelling. It should contain only the Ys and Xs for the model
#' @return A list with the ascribed variable and some statistics
#' @examples
#' ascription.model()
#' @export

# ?????? How the sampling for the training dataset will be implemented
# ?????? How the merging of the predicted values will be implemented

ascription.model <- function(Y.var, data, trainInd){
  if(class(Y.var) != "character") {
    Y.var <- colnames(data)[Y.var]
  }
  
  currentF <- formula(paste0(Y.var, " ~ ."))  
  
  simulateData <- data
  rm(data)
  
  simulateDataTrain <- simulateData[trainInd,]
  simrowsTrain <- nrow(simulateDataTrain)
  
  treeBucket <- c(ifelse(simrowsTrain<100,round_any(simrowsTrain,10,f=floor),
                         ifelse(simrowsTrain<200,100,
                                ifelse(simrowsTrain<900,round_any(simrowsTrain,200,f=floor),
                                       ifelse(simrowsTrain<2000,800,1200)))))
  
  set.seed(35)
  CRF.fit <- party::cforest(formula=currentF,
                            data = simulateDataTrain,
                            controls=cforest_unbiased(ntree=treeBucket[1],
                                                      mtry=initialBucket[1])) 
  
  return(CRF.fit)
}