#' Recursively traverses a tree and gets the names of the splitting variables
#'
#' @param node - binary tree resulting from ctree call
#' @return a character vector with variable names
#' @export

getTreeVars <- function(node){

  if(class(node) == "BinaryTree") node <- node@tree

  if(node$terminal){
    return(NULL)
  } else {

    a <- c(node$psplit$variableName, getTreeVars(node$left), getTreeVars(node$right))
    return(a)
  }
}

