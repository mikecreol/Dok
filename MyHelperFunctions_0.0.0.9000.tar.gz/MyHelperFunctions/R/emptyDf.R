#' Initializes empty dataframe usually for cbind and rbind
#'
#' @param axis - determines whether by rows or columns. 1 rows, 2 columns  
#' @param names - are either colnames or rownames depending on axis
#' @param number - are either colnames or rownames depending on axis
#' @return an empty dataframe
#' @export
#' 

emptyDf <- function(axis = 2, names = NULL, number = length(names)){
  if(axis == 1){
    TempDf <- data.frame(bot = rep(0, number))
    if(!is.null(names)){
      rownames(TempDf) <- names
    }
    
    TempDf$bot <- NULL
    return(TempDf)
  } else if(axis == 2){
    if(!is.null(names)){
      TempDf <- as.data.frame(setNames(replicate(number, numeric(0), simplify = F), names))
    } else {
      TempDf <- as.data.frame(setNames(replicate(number, numeric(0), simplify = F), paste0("Var_", 1:number)))
    }
    
    return(TempDf)
  }
}