#' Converts the character vars in a dataframe to factors
#'
#' @param y.name - a character vector for the dependent variable
#' @param x.vector - a character vector for the independent variable
#' @return a formula object
#' @export

create.formula <- function (y.name, x.vector){
  facts <- x.vector[1]
  if(length(x.vector) != 1){
    for (i in 2:length(x.vector)) {
      facts <- paste0(facts, " + ", x.vector[i])
    }
  }
  
  temp.formula <- formula(paste0(y.name, " ~ ", facts))
  return(temp.formula)
}