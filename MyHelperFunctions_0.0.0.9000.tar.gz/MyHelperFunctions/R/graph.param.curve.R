#' Function for graphing a parametric curve in R2
#' 
#' Takes as input the two functions for the x and y coordinates and the limits for the t variable
#' @param x a function of t specifying the horizontal axis in the plane
#' @param y a function of t specifying the vertical axis in the plane
#' @param tlim specifying the interval in which t would change
#' @return The plot of the parametric curve
#' @export 

graph.param.curve <- function(x = t, y = t, tlim = c(0,1), ...){
  t <- seq(tlim[1], tlim[2], by=0.01)
  
  a <- eval(substitute(x))
  b <- eval(substitute(y))
  
  try({
    if(class(x) == "character"){
      a <- eval(parse(text = x))
      b <- eval(parse(text = y))
    }
  }, silent = TRUE)
  
  plot(a,b, ...)
}

# graph.param.curve(x = 16*sin(t)^3, 
#                    y = 13*cos(t)-5*cos(2*t)-2*cos(3*t)-cos(4*t),
#                    # y = function(t) t,
#                    tlim = c(0, 2*pi),
#                    type = "l")

# graph.param.curve3(x = "16*sin(t)^3", 
#                    y = "13*cos(t)-5*cos(2*t)-2*cos(3*t)-cos(4*t)",
#                    # y = function(t) t,
#                    tlim = c(0, 2*pi),
#                    type = "l")


