#' Finds the last two digits in a string vector
#'
#' @param x - a character vector
#' @return returns the last two digits if there are any; else it returns NA
#' @export

lastNumber <- function(x){
  numericValues <- as.character(0:9)
  
  newVec <- character(length(x))
  for(i in 1:length(x)){
    a <- x[i]
    
    for(j in nchar(a):1){
      charValue <- substr(a, j, j)
      if(charValue %in% numericValues){
        newVec[i] <- paste0(charValue, newVec[i])
      } else {
        break
      }
    }
  }
  
  newVec <- ifelse(newVec == "", NA, newVec)
  
  return(newVec)
}

