#' Equates the levels of factors in two dataframes with the same factor variables
#'
#' @param olddata - dataframe from which the factor levels will be taken and applied to newdata
#' @param newdata - dataframe to which the old levels will be applied
#' @return a dataframe in which character variables are converted to factors
#' @export

oldLevels <- function(olddata, newdata){
  # a funtion that takes 3 arguments, old data, new data and varlist and returns a dataframe in which
  # the factor vars in the new data are with the same levels as in the old one

  # Create a new varlist with only factor variables
  factor.index <- sapply(olddata, is.factor)

  if(sum(factor.index) > 0){
    varlist.factors <- colnames(olddata)[factor.index]

    for(i in varlist.factors){
      newdata[[i]] <- factor(newdata[[i]], levels = levels(olddata[[i]]))
    }
  }

  return(newdata)
}
