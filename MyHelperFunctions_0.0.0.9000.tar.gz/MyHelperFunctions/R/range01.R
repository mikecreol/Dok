#' Scales a numeric vector in the interval 0 to 1 based on the maximum and minimum value in this vector
#'
#' @param x - a numeric vector
#' @return a numeric vector in the interval 0 to 1
#' @export

range01 <- function(x, ...){(x - min(x, ...)) / (max(x, ...) - min(x, ...))}