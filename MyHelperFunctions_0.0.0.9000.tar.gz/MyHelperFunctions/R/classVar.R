#' Groups a numeric variable
#'
#' @param x - a character vector for the dependent variable
#' @param step - a character vector for the independent variable
#' @return a dataframe with frequency
#' @export


classVar <- function(x, step = 10){
  percent <- function(x, digits = 2, format = "f", ...) {
    paste0(formatC(100 * x, format = format, digits = digits, ...), "%")
  }
  
  varName <- deparse(substitute(x))
  
  xNAs <- x
  xNAs <- as.character(xNAs)
  x <- na.omit(x)
  
  if(is.character(x) | is.factor(x)){
    returnVec <- as.character(x)
  } else {
    returnVec <- cut(x, c(-Inf,seq(min(x), max(x), step), max(x)), right = TRUE, include.lowest = F)
    returnVec <- as.character(returnVec)
  }
  
  xNAs[which(!is.na(xNAs))] <- returnVec
  returnVec <- xNAs
  
  returnList <- list()
  
  returnList$x <- returnVec
  
  Df <- cbind(table(returnVec))
  Df <- as.data.frame(Df)
  Df <- Df[order(rownames(Df)), ,drop = F]
  colnames(Df) <- varName
  
  Df$Perc <- as.numeric(as.matrix(Df[1] / sum(Df[1])))
  Df$CumPerc <- cumsum(as.numeric(as.matrix(Df[1] / sum(Df[1]))))
  
  Df$Perc <- percent(Df$Perc)
  Df$CumPerc <- percent(Df$CumPerc)
  
  returnList$Df <- Df
  
  return(returnList)
}