#' Replaces dots in column names of a dataframe
#'
#' The function replaces dots with "_" in column names of a dataframe and returns the dataframe
#' @param df - dataframe whose column names will be replaced with
#' @return a dataframe with renamed columns
#' @export

dotReplace <- function(df){
  colnames(df) <- gsub("\\.", "_", colnames(df))
  return(df)
}







